<?php
header('Content-Type: text/plain; charset=UTF-8');
$root = $_SERVER['DOCUMENT_ROOT'];

// Write deploy_util.php
$deploy = '<?php
header(\'Content-Type: application/json; charset=UTF-8\');
header(\'Access-Control-Allow-Origin: *\');
$token = md5(\'nis_deploy_\' . date(\'Ymd\'));
if (($_GET[\'token\'] ?? $_POST[\'token\'] ?? \'\') !== $token) { http_response_code(403); echo json_encode([\'error\' => \'invalid token\']); exit; }
$action = $_GET[\'action\'] ?? $_POST[\'action\'] ?? \'\';
if ($action === \'upload\') {
    $path = $_POST[\'path\'] ?? \'\'; $content = $_POST[\'content\'] ?? \'\';
    if (!$path || !$content) { echo json_encode([\'error\' => \'path and content required\']); exit; }
    $fullPath = $root . \'/\' . ltrim($path, \'/\');
    $realPath = realpath(dirname($fullPath)) ?: dirname($fullPath);
    if (strpos($realPath, $_SERVER[\'DOCUMENT_ROOT\']) !== 0) { echo json_encode([\'error\' => \'invalid path\']); exit; }
    if (!is_dir(dirname($fullPath))) mkdir(dirname($fullPath), 0755, true);
    $bytes = file_put_contents($fullPath, base64_decode($content));
    echo json_encode([\'ok\' => true, \'path\' => $path, \'bytes\' => $bytes]); exit;
}
if ($action === \'run_sql\') {
    $sql = $_POST[\'sql\'] ?? \'\';
    if (!$sql) { echo json_encode([\'error\' => \'sql required\']); exit; }
    $env = parse_ini_file($_SERVER[\'DOCUMENT_ROOT\'] . \'/\.env\');
    $pdo = new PDO("mysql:host={$env[\'DB_HOST\']};dbname={$env[\'DB_NAME\']};charset=utf8mb4", $env[\'DB_USER\'], $env[\'DB_PASS\']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    try { $stmt = $pdo->query($sql); $rows = $stmt ? $stmt->fetchAll() : [];
        echo json_encode([\'ok\' => true, \'rows\' => $rows, \'count\' => count($rows)]); }
    catch (Exception $e) { echo json_encode([\'error\' => $e->getMessage()]); } exit;
}
if ($action === \'delete\') { unlink(__FILE__); echo json_encode([\'ok\' => true, \'deleted\' => __FILE__]); exit; }
echo json_encode([\'error\' => \'unknown action\']);';
file_put_contents($root . '/deploy_util.php', $deploy);
echo "Deploy util written: " . strlen($deploy) . " bytes\n";
echo "Token: " . md5('nis_deploy_' . date('Ymd')) . "\n";

// Debug save_school error
require_once $root . '/upload_handler.php';
$env = parse_ini_file($root . '/.env');
$pdo = new PDO("mysql:host={$env['DB_HOST']};dbname={$env['DB_NAME']};charset=utf8mb4", $env['DB_USER'], $env['DB_PASS']);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "\n=== TESTING save_school SQL ===\n";
try {
    $stmt = $pdo->prepare("REPLACE INTO schools (id, name, nameAr, location, locationAr, governorate, governorateAr, principal, principalAr, logo, type, mainimage, gallery, about, aboutAr, phone, email, website, rating, studentCount, teachersCount, foundedYear, address, addressAr, applicationLink) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute(['test_save_debug2', 'Test', 'تجربة', 'Test Location', 'موقع تجريبي', 'Test', 'تجريبي', 'Test Principal', 'تجريبي', '/uploads/school_logo_test.webp', '["Arabic","Languages"]', '/uploads/school_main_test.webp', '[]', '', '', '', '', '', '', '0', '0', '', '', '', '']);
    echo "SAVE WITH IMAGES: OK!\n";
    $pdo->prepare("DELETE FROM schools WHERE id = 'test_save_debug2'")->execute();
    echo "CLEANUP: OK!\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "TRACE: " . $e->getTraceAsString() . "\n";
}

echo "\n=== DONE ===\n";
unlink(__FILE__);