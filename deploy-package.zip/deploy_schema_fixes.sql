-- ========================================================================
-- Deployment SQL - Run on phpMyAdmin BEFORE uploading new files
-- Database: ganiedu_nis_db
-- IMPORTANT: MySQL 8.0 does NOT support 'IF NOT EXISTS' for ALTER TABLE ADD COLUMN
-- If you get "Duplicate column name" error, it means the column already exists.
-- Just ignore the error and continue.
-- ========================================================================

-- 1. Add modification_approved to admissions status ENUM
ALTER TABLE admissions MODIFY COLUMN status ENUM('pending','under_review','accepted','waitlist','rejected','modification_requested','modification_approved') DEFAULT 'pending';

-- 2. Add modification_requests history columns (safe for MySQL 8.0)
ALTER TABLE modification_requests ADD COLUMN old_preferences JSON AFTER requested_preferences;
ALTER TABLE modification_requests ADD COLUMN original_status VARCHAR(50) AFTER admission_id;

-- 3. Increase column widths to match schema (phone and email were too narrow)
ALTER TABLE schools MODIFY COLUMN phone VARCHAR(100);
ALTER TABLE schools MODIFY COLUMN email VARCHAR(255);

-- 4. Add resume_data column for CV preview in job applications
ALTER TABLE job_applications ADD COLUMN resume_data LONGTEXT;

-- 5. Add teachersCount column to schools if missing
ALTER TABLE schools ADD COLUMN IF NOT EXISTS teachersCount VARCHAR(50) DEFAULT '0';

-- 6. Verify columns exist (informational queries - uncomment to run)
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'ganiedu_nis_db' AND TABLE_NAME = 'schools';
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'ganiedu_nis_db' AND TABLE_NAME = 'job_applications';
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'ganiedu_nis_db' AND TABLE_NAME = 'admissions';
-- SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'ganiedu_nis_db' AND TABLE_NAME = 'modification_requests';